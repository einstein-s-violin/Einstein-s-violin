// pages/hecheng/hecheng.js
const app = getApp()

Page({
  data: {
    result: "暂无结果",
    shuru: ''
  },
  //事件处理函数
  calculate: function () {
    wx.request({
      url: 'http://e2394720g4.zicp.vip/hecheng',
      data: {
        shuru: this.data.shuru
      },
      success: res => {
        if (res.statusCode == 200) {
          this.setData({
            result: res.data
          })
        }
      }
    })
  },
  input: function (e) {
    this.setData({
      shuru: e.detail.value
    })
  }
})
