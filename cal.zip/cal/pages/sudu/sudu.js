// pages/sudu/sudu.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    screenData: '0',
    x1: '',
    v01: '',
    t1: '',
    x2: '',
    v02: '',
    v2: '',
    v03: '',
    v3: '',
    t3: '',
    n4: '',
    m4: '',
  },


  x1Input(e) {
    this.setData({
      x1: e.detail.value
    })
  },
  v01Input(e) {
    this.setData({
      v01: e.detail.value
    })
  },
  t1Input(e) {
    this.setData({
      t1: e.detail.value
    })
  },

  x2Input(e) {
    this.setData({
      x2: e.detail.value
    })
  },
  v02Input(e) {
    this.setData({
      v02: e.detail.value
    })
  },
  v2Input(e) {
    this.setData({
      v2: e.detail.value
    })
  },

  v03Input(e) {
    this.setData({
      v03: e.detail.value
    })
  },
  v3Input(e) {
    this.setData({
      v3: e.detail.value
    })
  },
  t3Input(e) {
    this.setData({
      t3: e.detail.value
    })
  },

  n4Input(e) {
    this.setData({
      n4: e.detail.value
    })
  },
  m4Input(e) {
    this.setData({
      m4: e.detail.value
    })
  },


  aBtn: function () {
    var data = this.data.screenData;
    var a = this.data.x1;
    var b = this.data.v01;
    var c = this.data.t1;

    data = 2 * (a - b * c) / (c * c);

    this.setData({ "screenData": '加速度a= ' + data + ' m/s^2' });
  },

  bBtn: function () {
    var data = this.data.screenData;
    var a = this.data.x2;
    var b = this.data.v02;
    var c = this.data.v2;

    data = (c * c - b * b) / (2 * a);

    this.setData({ "screenData": '加速度a= ' + data + ' m/s^2' });
  },

  cBtn: function () {
    var data = this.data.screenData;
    var a = this.data.t3;
    var b = this.data.v03;
    var c = this.data.v3;

    data = (c - b) / a;

    this.setData({ "screenData": '加速度a= ' + data + ' m/s^2' });
  },

  dBtn: function () {
    var data = this.data.screenData;
    var a = this.data.n4;
    var b = this.data.m4;

    data = a / b;

    this.setData({ "screenData": '加速度a= ' + data + ' m/s^2' });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})