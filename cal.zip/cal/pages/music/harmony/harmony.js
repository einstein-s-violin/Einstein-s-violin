// pages/yinli/yinli.js
Page({
  data: {
    frequency1: '',
    frequency2: '',
    result: '0',
    screenData: '判断中',
  },

  frequency1Input(e) {
    this.setData({
      frequency1: e.detail.value
    })
  },
  frequency2Input(e) {
    this.setData({
      frequency2: e.detail.value
    })
  },


  calculateBtn: function () {
    var data = this.data.result;
    var a = this.data.frequency1;
    var b = this.data.frequency2;

    if ((a/b).toFixed(2)==1){
      this.setData({ "screenData": '完全一度' });
    }
    else if ((a / b).toFixed(2) == (16 / 15).toFixed(2)) {
      this.setData({ "screenData": '小二度' });
    }
    else if ((a / b).toFixed(2) == (9 / 8).toFixed(2)) {
      this.setData({ "screenData": '大二度' });
    }
    else if ((a / b).toFixed(2) == (6 / 5).toFixed(2)) {
      this.setData({ "screenData": '小三度' });
    }
    else if ((a / b).toFixed(2) == (5 / 4).toFixed(2)) {
      this.setData({ "screenData": '大三度' });
    }
    else if ((a / b).toFixed(2) == (4 / 3).toFixed(2)) {
      this.setData({ "screenData": '完全四度' });
    }
    else if ((a / b).toFixed(2) == (45 / 32).toFixed(2)) {
      this.setData({ "screenData": '增四度' });
    }
    else if ((a / b).toFixed(2) == (64 / 45).toFixed(2)) {
      this.setData({ "screenData": '减四度' });
    }
    else if ((a / b).toFixed(2) == (3 / 2).toFixed(2)) {
      this.setData({ "screenData": '完全五度' });
    }
    else if ((a / b).toFixed(2) == (8 / 5).toFixed(2)) {
      this.setData({ "screenData": '小六度' });
    }
    else if ((a / b).toFixed(2) == (5 / 3).toFixed(2)) {
      this.setData({ "screenData": '大六度' });
    }
    else if ((a / b).toFixed(2) == (16 / 9).toFixed(2)) {
      this.setData({ "screenData": '小七度' });
    }
    else if ((a / b).toFixed(2) == (15 / 8).toFixed(2)) {
      this.setData({ "screenData": '大七度' });
    }
    else if ((a / b).toFixed(2) == 2) {
      this.setData({ "screenData": '完全八度' });
    }
  },

})