// pages/music/compare/compare.js
const c4 = wx.createInnerAudioContext();
const d4 = wx.createInnerAudioContext();
const e4 = wx.createInnerAudioContext();
const f4 = wx.createInnerAudioContext();
const g4 = wx.createInnerAudioContext();
const a5 = wx.createInnerAudioContext();
const b5 = wx.createInnerAudioContext();
var A1 = Math.floor(Math.random() * 7);
var A2 = Math.floor(Math.random() * 7);
var B2 = Math.floor(Math.random() * 7);


Page({
  data :{
    bc_default: '#FBFBFB',
    bc_right: '#98FB98',
    bc_wrong: '#FF99B4',
    bcA: '',
    bcB: '',
    bcC: '',
    A1 : '',
    A2 : '',
    B2 : '',
  },

  abs: function (n){
    if (n > 0) return n;
    else return -n;
  },

  onShow: function () {
    c4.src = "/images/C4.mp3";
    d4.src = "/images/D4.mp3";
    e4.src = "/images/E4.mp3";
    f4.src = "/images/F4.mp3";
    g4.src = "/images/G4.mp3";
    a5.src = "/images/A5.mp3";
    b5.src = "/images/B5.mp3";
  },

  clickBtnA1: function (event) {
    if (A1 == 1) {
      c4.play();
      console.log(c4.duration);}
    if (A1 == 2) {
      d4.play();
      console.log(d4.duration);
    }
    if (A1 == 3) {
      e4.play();
      console.log(e4.duration);
    }
    if (A1 == 4) {
      f4.play();
      console.log(f4.duration);
    }
    if (A1 == 5) {
      g4.play();
      console.log(g4.duration);
    }
    if (A1 == 6) {
      a5.play();
      console.log(a5.duration);
    }
    if (A1 == 0) {
      b5.play();
      console.log(b5.duration);
    }

  },
  clickBtnA2: function (event) {
    if (A2 == 1) {
      c4.play();
      console.log(c4.duration);
    }
    if (A2 == 2) {
      d4.play();
      console.log(d4.duration);
    }
    if (A2 == 3) {
      e4.play();
      console.log(e4.duration);
    }
    if (A2 == 4) {
      f4.play();
      console.log(f4.duration);
    }
    if (A2 == 5) {
      g4.play();
      console.log(g4.duration);
    }
    if (A2 == 6) {
      a5.play();
      console.log(a5.duration);
    }
    if (A2 == 0) {
      b5.play();
      console.log(b5.duration);
    }

  },
  clickBtnB2: function (event) {
    if (B2 == 1) {
      c4.play();
      console.log(c4.duration);
    }
    if (B2 == 2) {
      d4.play();
      console.log(d4.duration);
    }
    if (B2 == 3) {
      e4.play();
      console.log(e4.duration);
    }
    if (B2 == 4) {
      f4.play();
      console.log(f4.duration);
    }
    if (B2 == 5) {
      g4.play();
      console.log(g4.duration);
    }
    if (B2 == 6) {
      a5.play();
      console.log(a5.duration);
    }
    if (B2 == 0) {
      b5.play();
      console.log(b5.duration);
    }
  },

  /*nextQuestion: function () {
    var that = this;
      this.setData({
        bcA: that.data.bc_default,
        bcB: that.data.bc_default,
        bcC: that.data.bc_default,
      });
    
  },*/

  btnOpClick: function (e){
    var that = this;
    var select = e.currentTarget.id;
      if (this.abs(A1-A2)>this.abs(A1-B2)){
        if (select == 'A') { this.setData({ bcA: that.data.bc_right });}
        else if (select == 'B') {
          this.setData({ bcB: that.data.bc_wrong });
        }
        else if (select == 'C') {
          this.setData({ bcC: that.data.bc_wrong });
        }
        that.gotonext();
      }
      else if (this.abs(A1 - A2) < this.abs(A1 - B2)) {
        if (select == 'A') { this.setData({ bcA: that.data.bc_wrong }); }
        else if (select == 'B') {
          this.setData({ bcB: that.data.bc_right });
        }
        else if (select == 'C') {
          this.setData({ bcC: that.data.bc_wrong });
        }
        that.gotonext();
      }
      else if (this.abs(A1 - A2) == this.abs(A1 - B2)) {
        if (select == 'A') { this.setData({ bcA: that.data.bc_wrong }); }
        else if (select == 'B') {
          this.setData({ bcB: that.data.bc_wrong });
        }
        else if (select == 'C') {
          this.setData({ bcC: that.data.bc_right });
        }
        that.gotonext();
      }

  },

  gotonext: function () {
    wx.navigateTo({
      url: '../compare/compare',
    })
  },


  
})