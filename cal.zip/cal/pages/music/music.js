// pages/music/music.js
// pages/music/music.js
const c4 = wx.createInnerAudioContext();
const d4 = wx.createInnerAudioContext();
const e4 = wx.createInnerAudioContext();
const f4 = wx.createInnerAudioContext();
const g4 = wx.createInnerAudioContext();
const a5 = wx.createInnerAudioContext();
const b5 = wx.createInnerAudioContext();

Page({

  data: {
    //isplay: false,//是否播放

    idb: "back",
    idc: "clear",
    idt: "toggle",
    idadd: "＋",
    id9: "9",
    id8: "8",
    id7: "7",
    idj: "－",
    id6: "6",
    id5: "5",
    id4: "4",
    idx: "×",
    id3: "3",
    id2: "2",
    id1: "1",
    iddiv: "÷",
    id0: "0",
    idd: ".",
    ide: "＝",
    screenData: "0",
    operaSymbo: { "＋": "+", "－": "-", "×": "*", "÷": "/", ".": "." },
    lastIsOperaSymbo: false,
    iconType: 'waiting_circle',
    iconColor: 'white',
    arr: [],
    logs: []
  },
  onShow: function () {
    c4.src = "/images/C4.mp3";
    d4.src = "/images/D4.mp3";
    e4.src = "/images/E4.mp3";
    f4.src = "/images/F4.mp3";
    g4.src = "/images/G4.mp3";
    a5.src = "/images/A5.mp3";
    b5.src = "/images/B5.mp3";
  },
  
  clickBtn1: function (event) {
    c4.play();
    console.log(c4.duration);
  },
  clickBtn2: function (event) {
    d4.play();
    console.log(d4.duration);
  },
  clickBtn3: function (event) {
    e4.play();
    console.log(e4.duration);
  },
  clickBtn4: function (event) {
    f4.play();
    console.log(f4.duration);
  },
  clickBtn5: function (event) {
    g4.play();
    console.log(g4.duration);
  },
  clickBtn6: function (event) {
    a5.play();
    console.log(a5.duration);
  },
  clickBtn7: function (event) {
    b5.play();
    console.log(b5.duration);
  },

  gotoharm: function () {
    wx.navigateTo({
      url: '../music/harmony/harmony'
    })
  },
  gotocom: function () {
    wx.navigateTo({
      url: '../music/compare/compare'
    })
  },
})
