// pages/wendu/wendu.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    screenData:'0',
    wendu:'',
  },

  wenduInput(e) {
    this.setData({
      wendu: e.detail.value
    })
  },
//摄氏度的转换
  c1Btn: function () {
    var data = this.data.screenData;
    var a = this.data.wendu;
    data = a*1.8+32;
    this.setData({ "screenData": data + '℉' });
  },
  c2Btn: function () {
    var data = this.data.screenData;
    var a = this.data.wendu;
    data = a*1.8+32+459.67;
    this.setData({ "screenData": data + 'Ra' });
  },
  c3Btn: function () {
    var data = this.data.screenData;
    var a = this.data.wendu;
    data = a*0.8;
    this.setData({ "screenData": data + 'R' });
  },

//华氏度的转换
  h1Btn: function () {
    var data = this.data.screenData;
    var a = this.data.wendu;
    data = (a-32)/1.8
    this.setData({ "screenData": data + '℃' });
  },
  h2Btn: function () {
    var data = this.data.screenData;
    var a = this.data.wendu;
    data = a+459.67;
    this.setData({ "screenData": data + 'Ra' });
  },
  h3Btn: function () {
    var data = this.data.screenData;
    var a = this.data.wendu;
    data = (a-32)/2.25;
    this.setData({ "screenData": data + 'R' });
  },

//兰氏度的转换
  l1Btn: function () {
    var data = this.data.screenData;
    var a = this.data.wendu;
    data = (a-32-459.67)/1.8;
    this.setData({ "screenData": data + '℃' });
  },
  l2Btn: function () {
    var data = this.data.screenData;
    var a = this.data.wendu;
    data = a-459.67;
    this.setData({ "screenData": data + '℉' });
  },
  l3Btn: function () {
    var data = this.data.screenData;
    var a = this.data.wendu;
    data = (a-459.67-32)/2.25;
    this.setData({ "screenData": data + 'R' });
  },

//列氏度的转换
  n1Btn: function () {
    var data = this.data.screenData;
    var a = this.data.wendu;
    data = a*1.25;
    this.setData({ "screenData": data + '℃' });
  },
  n2Btn: function () {
    var data = this.data.screenData;
    var a = this.data.wendu;
    data = a*2.25+32;
    this.setData({ "screenData": data + '℉' });
  },
  n3Btn: function () {
    var data = this.data.screenData;
    var a = this.data.wendu;
    data = a*2.25+32+459.67;
    this.setData({ "screenData": data + 'Ra' });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})