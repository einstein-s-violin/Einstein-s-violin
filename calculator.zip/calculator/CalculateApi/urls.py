from django.conf.urls import url
from . import views
from . import sincos
from . import hecheng
from . import fenjie

urlpatterns = [
    url('calculate', views.calculate),
    url('sincos', sincos.pic),
    url('hecheng', hecheng.pic),
    url('fenjie', fenjie.pic)

]
