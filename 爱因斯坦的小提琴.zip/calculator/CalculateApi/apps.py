from django.apps import AppConfig


class CalculateapiConfig(AppConfig):
    name = 'CalculateApi'
