from django.http import HttpResponse
from pylab import *
import numpy as np

def pic(request):
    shuru = request.GET['shuru']

    f = int(shuru.split(',')[0])
    f1 = int(shuru.split(',')[1])
    theta = int(shuru.split(',')[2])
    th = theta*np.pi /180
    f1x = f1
    f1y = 0
    fx = f*cos(th)
    fy = f*sin(th)
    f2x = fx - f1x
    f2y = fy - f1y
    f2 = sqrt(f2x^2 , f2y ^2)
    # 创建一个 8 * 6 点（point）的图，并设置分辨率为 80
    figure(figsize=(8,6), dpi=80)

    # 创建一个新的 1 * 1 的子图，接下来的图样绘制在其中的第 1 块（也是唯一的一块）
    subplot(1,1,1)
    #plt.axis([0,0.1,0,0.2])


    quiver(0,0,f1x,f1y,color='black', width=0.005, scale=50)
    quiver(0,0,f2x,f2y,color='r', width=0.005, scale=50)
    quiver(0,0,fx,fy,color='black', width=0.005, scale=50)
    quiver(f1x,f1y,fx,fy,color='white')
    quiver(f2x,f2y,fx,fy,color='white')

    # save
    plt.savefig('C:/Users/LENOVO/Desktop/123/cal/Images/fenjie.png')
    return HttpResponse( f2, content_type='text/plain;charset=utf-8')

#pic(10,10,45)