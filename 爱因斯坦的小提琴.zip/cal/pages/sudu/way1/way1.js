// pages/sudu/way1/way1.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    screenData: '0',
    x2: '',
    v02: '',
    v2: '',
  },

  x2Input(e) {
    this.setData({
      x2: e.detail.value
    })
  },
  v02Input(e) {
    this.setData({
      v02: e.detail.value
    })
  },
  v2Input(e) {
    this.setData({
      v2: e.detail.value
    })
  },

  bBtn: function () {
    var data = this.data.screenData;
    var a = this.data.x2;
    var b = this.data.v02;
    var c = this.data.v2;

    data = (c * c - b * b) / (2 * a);

    this.setData({ "screenData": '加速度a= ' + data + ' m/s^2' });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})