// pages/sudu/way2/way2.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    screenData: '0',
    v03: '',
    v3: '',
    t3: '',
  },

  v03Input(e) {
    this.setData({
      v03: e.detail.value
    })
  },
  v3Input(e) {
    this.setData({
      v3: e.detail.value
    })
  },
  t3Input(e) {
    this.setData({
      t3: e.detail.value
    })
  },

  cBtn: function () {
    var data = this.data.screenData;
    var a = this.data.t3;
    var b = this.data.v03;
    var c = this.data.v3;

    data = (c - b) / a;

    this.setData({ "screenData": '加速度a= ' + data + ' m/s^2' });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})