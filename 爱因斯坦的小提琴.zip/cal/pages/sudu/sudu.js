// pages/sudu/sudu.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    screenData: '0',
    x1: '',
    v01: '',
    t1: '',
  },


  x1Input(e) {
    this.setData({
      x1: e.detail.value
    })
  },
  v01Input(e) {
    this.setData({
      v01: e.detail.value
    })
  },
  t1Input(e) {
    this.setData({
      t1: e.detail.value
    })
  },


  aBtn: function () {
    var data = this.data.screenData;
    var a = this.data.x1;
    var b = this.data.v01;
    var c = this.data.t1;

    data = 2 * (a - b * c) / (c * c);

    this.setData({ "screenData": '加速度a= ' + data + ' m/s^2' });
  },
  
  gotoway1: function () {
    wx.navigateTo({
      url: '../sudu/way1/way1'
    })
  },
  gotoway2: function () {
    wx.navigateTo({
      url: '../sudu/way2/way2'
    })
  },
  gotoway3: function () {
    wx.navigateTo({
      url: '../sudu/way3/way3'
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})