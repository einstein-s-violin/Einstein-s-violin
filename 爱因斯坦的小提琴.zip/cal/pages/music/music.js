// pages/music/music.js
// pages/music/music.js
const c3 = wx.createInnerAudioContext();
const d3 = wx.createInnerAudioContext();
const e3 = wx.createInnerAudioContext();
const f3 = wx.createInnerAudioContext();
const g3 = wx.createInnerAudioContext();
const a4 = wx.createInnerAudioContext();
const b4 = wx.createInnerAudioContext();
const c4 = wx.createInnerAudioContext();
const d4 = wx.createInnerAudioContext();
const e4 = wx.createInnerAudioContext();
const f4 = wx.createInnerAudioContext();
const g4 = wx.createInnerAudioContext();
const a5 = wx.createInnerAudioContext();
const b5 = wx.createInnerAudioContext();
const c5 = wx.createInnerAudioContext();
const d5 = wx.createInnerAudioContext();
const e5 = wx.createInnerAudioContext();
const f5 = wx.createInnerAudioContext();
const g5 = wx.createInnerAudioContext();


Page({

  data: {
    //isplay: false,//是否播放

    idb: "back",
    idc: "clear",
    idt: "toggle",
    idadd: "＋",
    id9: "9",
    id8: "8",
    id7: "7",
    idj: "－",
    id6: "6",
    id5: "5",
    id4: "4",
    idx: "×",
    id3: "3",
    id2: "2",
    id1: "1",
    iddiv: "÷",
    id0: "0",
    idd: ".",
    ide: "＝",
    screenData: "0",
    operaSymbo: { "＋": "+", "－": "-", "×": "*", "÷": "/", ".": "." },
    lastIsOperaSymbo: false,
    iconType: 'waiting_circle',
    iconColor: 'white',
    arr: [],
    logs: []
  },
  onShow: function () {
    c3.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/C3.MP3?sign=d65b4eae1e19d043b2b8a6c1c6bf6129&t=1553842604";
    d3.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/D3.MP3?sign=14968bcd671e3d685a516396a2f2ae6e&t=1553842636";
    e3.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/E3.MP3?sign=b32d95f61c5710aa99bc9785f2661362&t=1553842677";
    f3.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/F3.MP3?sign=56dea5f97070d62904df96746078803c&t=1553842723";
    g3.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/G3.MP3?sign=7b55bc0659383a69b33dd3afe45cbad5&t=1553842758";
    a4.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/A4.MP3?sign=bc4effaf06950c3f411e349abf69341a&t=1553842517";
    b4.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/B4.MP3?sign=caa9693d0d2863cfe8a959a23c17377a&t=1553842572";
    c4.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/C4.MP3?sign=8aaba375b9a787312268463103284a61&t=1553842285";
    d4.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/D4.MP3?sign=8e03dbc978005e95ad6649f7b2b2961f&t=1553842651";
    e4.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/E4.MP3?sign=bde3be3bbe8e0aedc5734ca24ff79e6d&t=1553842692";
    f4.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/F4.MP3?sign=a488e93cf4c5d33b1c0a39bd90edf821&t=1553842736";
    g4.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/G4.MP3?sign=e516acb6c2b32ee0f51b54b86fc3be43&t=1553842774";
    a5.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/A5.MP3?sign=b29735db0145b884525826b38de3b9aa&t=1553842551";
    b5.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/B5.MP3?sign=fc29a6a28fe65f320473f10541bb3a33&t=1553842589";
    c5.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/C5.MP3?sign=d213f286cfce5f0347d9fcaa611d2352&t=15538426233";
    d5.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/D5.MP3?sign=d4e1e9e234ef066b36cb52b050fc71ca&t=1553842663";
    e5.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/E5.MP3?sign=b3554dd6f4153246986317fb25e1aafe&t=1553842704";
    f5.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/F5.MP3?sign=291640ad777d410fb966696c163a3053&t=1553842747";
    g5.src = "https://6361-cal-3c0cf8-1258927142.tcb.qcloud.la/G5.MP3?sign=0128a04026269355b8de6a9018e08b2e&t=1553842787";
  },
  
  clickBtn1: function (event) {
    c4.play();
    console.log(c4.duration);
  },
  clickBtn2: function (event) {
    d4.play();
    console.log(d4.duration);
  },
  clickBtn3: function (event) {
    e4.play();
    console.log(e4.duration);
  },
  clickBtn4: function (event) {
    f4.play();
    console.log(f4.duration);
  },
  clickBtn5: function (event) {
    g4.play();
    console.log(g4.duration);
  },
  clickBtn6: function (event) {
    a5.play();
    console.log(a5.duration);
  },
  clickBtn7: function (event) {
    b5.play();
    console.log(b5.duration);
  },
  clickBtn8: function (event) {
    c5.play();
    console.log(c5.duration);
  }, 
  clickBtn9: function (event) {
    d5.play();
    console.log(d5.duration);
  },
  clickBtnC: function (event) {
    e5.play();
    console.log(e5.duration);
  },
   clickBtnpoint: function (event) {
    f5.play();
    console.log(f5.duration);
  }, 
  clickBtnxin: function (event) {
    g5.play();
    console.log(g5.duration);
  },
   clickBtnjia: function (event) {
    b4.play();
    console.log(b4.duration);
  }, 
  clickBtnjian: function (event) {
    a4.play();
    console.log(a4.duration);
  },
  clickBtncheng: function (event) {
    g3.play();
    console.log(g3.duration);
  },
  clickBtnchu: function (event) {
    f3.play();
    console.log(f3.duration);
  },
  clickBtndeng: function (event) {
    e3.play();
    console.log(e3.duration);
  },
  clickBtdian: function (event) {
    d3.play();
    console.log(d3.duration);
  },
  clickBtn0: function (event) {
    c3.play();
    console.log(c3.duration);
  },


  gotoharm: function () {
    wx.navigateTo({
      url: '../music/harmony/harmony'
    })
  },
  gotocom: function () {
    wx.navigateTo({
      url: '../music/compare/compare'
    })
  },
})
