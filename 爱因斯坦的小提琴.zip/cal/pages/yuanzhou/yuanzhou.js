// pages/yuanzhou/yuanzhou.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
     screenData1:'线速度v=0',
     screenData2:'角速度w=0',
     screenData3:'周期T=0',
     screenData4:'向心加速度an=0',
     screenData5:'向心力Fn=0',
     screenData:'0',
     m:'',
     r:'',
     n:'',
     π:'3.14',
  },

  mInput(e) {
    this.setData({
      m: e.detail.value
    })
  },
  rInput(e) {
    this.setData({
      r: e.detail.value
    })
  },
  nInput(e) {
    this.setData({
      n: e.detail.value
    })
  },

  calculateBtn: function () {
    var data1 = this.data.screenData;
    var data2 = this.data.screenData;
    var data3 = this.data.screenData;
    var data4 = this.data.screenData;
    var data5 = this.data.screenData;

    var m = this.data.m;
    var r = this.data.r;
    var n = this.data.n;
    var a = this.data.π;

    data1 = 2*a*r*n;
    data2 = 2*a*n;
    data3 = 1/n;
    data4 = 4*r*a*a*n*n;
    data5 = 4*r*m*a*a*n*n;

    this.setData({ "screenData1": '线速度v=' + data1 +' m/s'});
    this.setData({ "screenData2": '角速度w=' + data2 +' rad/s'});
    this.setData({ "screenData3": '周期T=' + data3 +' s'});
    this.setData({ "screenData4": '向心加速度an=' + data4 +' m/s^2'});
    this.setData({ "screenData5": '向心力Fn=' + data5 +' N'});
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})