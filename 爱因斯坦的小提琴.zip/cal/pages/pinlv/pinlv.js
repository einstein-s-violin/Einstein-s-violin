// pages/pinlv/pinlv.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    screenData: '0',
    input: '',
    c: '300000000',
  },
  pinlvInput(e) {
    this.setData({
      input: e.detail.value
    })
  },

  boBtn: function () {
    var data = this.data.screenData;
    var a = this.data.input;
    var b = this.data.c;

    data = b / a;
    this.setData({ "screenData": '频率' + a + 'Hz对应的波长为' + data + 'm' });
  },

  pinBtn: function () {
    var data = this.data.screenData;
    var a = this.data.input;
    var b = this.data.c;

    data = b / a;
    this.setData({ "screenData": '波长' + a + 'm对应的频率为' + data + 'Hz' });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})